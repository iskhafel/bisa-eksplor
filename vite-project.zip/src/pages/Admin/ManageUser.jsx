import Header from "../../components/Header";
import axios from "axios";
import { useState, useEffect } from "react";
import { Sidebar } from "flowbite-react";
import {
  HiUser,
  HiPhotograph,
  HiTag,
  HiViewGrid,
  HiOutlineClipboardList,
  HiShoppingCart,
} from "react-icons/hi";

export default function ManageUser() {
  const [user, setUser] = useState(null);

  const getUserProfile = () => {
    const token = localStorage.getItem("JWT_TOKEN");
    axios
      .get("https://travel-journal-api-bootcamp.do.dibimbing.id/api/v1/user", {
        headers: {
          Authorization: `Bearer ${token}`,
          apiKey: "24405e01-fbc1-45a5-9f5a-be13afcd757c",
        },
      })
      .then((response) => {
        console.log("User profile response:", response.data.data);
        setUser(response.data.data); // Set user data, including role
      })
      .catch((error) => {
        console.error("Failed to fetch user profile:", error);
      });
  };

  useEffect(() => {
    getUserProfile();
  }, []);

  return (
    <>
      <Header user={user} />
      <Sidebar aria-label="Admin Dashboard Sidebar" className="h-full w-48">
        <Sidebar.Items>
          <Sidebar.ItemGroup>
            <Sidebar.Item href="/dashboard/user" icon={HiUser}>
              User
            </Sidebar.Item>
            <Sidebar.Item href="/dashboard/banner" icon={HiPhotograph}>
              Banner
            </Sidebar.Item>
            <Sidebar.Item href="/dashboard/promo" icon={HiTag}>
              Promo
            </Sidebar.Item>
            <Sidebar.Item href="/dashboard/category" icon={HiViewGrid}>
              Category
            </Sidebar.Item>
            <Sidebar.Item
              href="/dashboard/activity"
              icon={HiOutlineClipboardList}
            >
              Activity
            </Sidebar.Item>
            <Sidebar.Item href="/dashboard/transaction" icon={HiShoppingCart}>
              Transaction
            </Sidebar.Item>
          </Sidebar.ItemGroup>
        </Sidebar.Items>
      </Sidebar>
    </>
  );
}
